package com.entity;

public enum IssueType {
    PRODUCT_BROKEN,
    PRODUCT_QUALITY,
    DELIVERY_ISSUE
}
